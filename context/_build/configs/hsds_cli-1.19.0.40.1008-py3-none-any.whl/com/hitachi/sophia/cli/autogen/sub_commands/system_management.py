# -*- coding: utf-8 -*-

"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""

import click
import collections
import json
import logging as loggingLib
import os
import re
import traceback
import errno

from com.hitachi.sophia.rest_client.manual.api_client import ApiClient
from com.hitachi.sophia.rest_client.manual.configuration import Configuration
from com.hitachi.sophia.rest_client.manual.rest import ApiException
from com.hitachi.sophia.cli.manual.command_util.object_array_util import ObjectArrayUtil
from com.hitachi.sophia.cli.manual.command_util.separate_args import SeparateArgs
from com.hitachi.sophia.cli.manual.message.message_management import MessageManagement
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.common_util import CommonUtil
from com.hitachi.sophia.cli.manual.util.uuid_util import UuidUtil
from com.hitachi.sophia.cli.manual.util.file_util import FileUtil
from com.hitachi.sophia.cli.manual.warning_banner import WarningBanner
from com.hitachi.sophia.cli.manual.version_check import VersionCheck
from com.hitachi.sophia.cli.manual.util.auth_parameters_util import AuthParametersUtil
from com.hitachi.sophia.cli.manual.util.output_util import OutputUtil
from com.hitachi.sophia.cli.manual.util.param_validator_util import ParamValidatorUtil

from uuid import UUID

logger = loggingLib.getLogger(__name__)



@click.command(options_metavar='<options>')
@click.option('--export_file_type','_export_file_type',type=str,metavar='<str>',help='Specifies the type of a configuration file to be output.(Cloud for AWS)(Cloud for Microsoft Azure)(Cloud for Google Cloud)')
@click.option('--machine_image_id','_machine_image_id',type=str,metavar='<str>',help='For the cloud model for Microsoft Azure, the resource ID of the VM image to be used for storage node addition or storage node replacement.For the cloud model for Google Cloud, the source image of the VM instance to be used for storage node addition or storage node replacement.(Cloud for AWS)(Cloud for Microsoft Azure)(Cloud for Google Cloud)')
@click.option('--number_of_drives','_number_of_drives',type=int,metavar='<int>',help='Number of drives to be installed per storage node after adding the drives.(Cloud for AWS)(Cloud for Microsoft Azure)(Cloud for Google Cloud)')
@click.option('--recover_single_drive','_recover_single_drive',metavar='<bool>',help='Whether to recover the drive that was removed for drive replacement.(Cloud for AWS)(Cloud for Google Cloud)')
@click.option('--drive_id','_drive_id',type=str,metavar='<str>',help='ID of the drive to be replaced.(Cloud for AWS)(Cloud for Google Cloud)')
@click.option('--recover_single_node','_recover_single_node',metavar='<bool>',help='Whether to recover a storage node that was removed for storage node replacement.(Cloud for Google Cloud)')
@click.option('--node_id','_node_id',type=str,metavar='<str>',help='ID of the storage node to be replaced.(Cloud for Google Cloud)')
@click.option('--template_s3_url','_template_s3_url',type=str,metavar='<str>',help='URL (https) of Amazon S3 where the VM configuration file is to be stored at the time of each maintenance operation.(Cloud for AWS)')
@click.option('--address_setting','_address_setting',metavar='<str>', multiple=True,help='Address setting parameter to be allocated to an additional node when adding the storage node.(Cloud for Microsoft Azure)(Cloud for Google Cloud) index: ID of the node to be added. control_port_ipv4_address: IP address (IPv4) of the control port. internode_port_ipv4_address: IP address (IPv4) of the internode port. compute_port_ipv4_address: IP address (IPv4) of the compute port. compute_port_ipv6_address: IP address (IPv6) of the compute port.')
def configuration_file_create(_export_file_type,_machine_image_id,_number_of_drives,_address_setting,_recover_single_drive,_drive_id,_recover_single_node,_node_id,_template_s3_url,):
    """
    Requests configuration file creation. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "configuration_file_create"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _export_file_type is not None:
            subCommandLogtxt += "--export_file_type " + str(_export_file_type) + " "




        if _machine_image_id is not None:
            subCommandLogtxt += "--machine_image_id " + str(_machine_image_id) + " "




        if _number_of_drives is not None:
            subCommandLogtxt += "--number_of_drives " + str(_number_of_drives) + " "



        if len(_address_setting) == 0:
            _address_setting = None

        if _address_setting is not None:
            subCommandLogtxt += "--address_setting " + str(_address_setting) + " "




        if _recover_single_drive is not None:
            subCommandLogtxt += "--recover_single_drive " + str(_recover_single_drive) + " "




        if _drive_id is not None:
            subCommandLogtxt += "--drive_id " + str(_drive_id) + " "




        if _recover_single_node is not None:
            subCommandLogtxt += "--recover_single_node " + str(_recover_single_node) + " "




        if _node_id is not None:
            subCommandLogtxt += "--node_id " + str(_node_id) + " "




        if _template_s3_url is not None:
            subCommandLogtxt += "--template_s3_url " + str(_template_s3_url) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        if _drive_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _drive_id):
            raise ValueError("Invalid value for `drive_id`, the format of UUID is invalid.")
        if _node_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _node_id):
            raise ValueError("Invalid value for `node_id`, the format of UUID is invalid.")
        


        
        


        
        
        
        
        
        #cliSubCommand = "configuration_file_create"



















        if _export_file_type is not None:
            if(isinstance(_export_file_type, str)):
                _export_file_type = SeparateArgs.check_backslash(_export_file_type)
                _export_file_type = _export_file_type.encode("utf-8").decode("unicode-escape")
        if _machine_image_id is not None:
            if(isinstance(_machine_image_id, str)):
                _machine_image_id = SeparateArgs.check_backslash(_machine_image_id)
                _machine_image_id = _machine_image_id.encode("utf-8").decode("unicode-escape")
        if _number_of_drives is not None:
            if(isinstance(_number_of_drives, str)):
                _number_of_drives = SeparateArgs.check_backslash(_number_of_drives)
                _number_of_drives = _number_of_drives.encode("utf-8").decode("unicode-escape")
        if _address_setting is not None:
            if(isinstance(_address_setting, str)):
                _address_setting = SeparateArgs.check_backslash(_address_setting)
                _address_setting = _address_setting.encode("utf-8").decode("unicode-escape")
        if _recover_single_drive is not None:
            if(isinstance(_recover_single_drive, str)):
                _recover_single_drive = SeparateArgs.check_backslash(_recover_single_drive)
                _recover_single_drive = _recover_single_drive.encode("utf-8").decode("unicode-escape")
        if _drive_id is not None:
            if(isinstance(_drive_id, str)):
                _drive_id = SeparateArgs.check_backslash(_drive_id)
                _drive_id = _drive_id.encode("utf-8").decode("unicode-escape")
        if _recover_single_node is not None:
            if(isinstance(_recover_single_node, str)):
                _recover_single_node = SeparateArgs.check_backslash(_recover_single_node)
                _recover_single_node = _recover_single_node.encode("utf-8").decode("unicode-escape")
        if _node_id is not None:
            if(isinstance(_node_id, str)):
                _node_id = SeparateArgs.check_backslash(_node_id)
                _node_id = _node_id.encode("utf-8").decode("unicode-escape")
        if _template_s3_url is not None:
            if(isinstance(_template_s3_url, str)):
                _template_s3_url = SeparateArgs.check_backslash(_template_s3_url)
                _template_s3_url = _template_s3_url.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.CreateConfigurationFileParam import CreateConfigurationFileParam
        _create_configuration_file_param = CreateConfigurationFileParam()
        _create_configuration_file_param.export_file_type = _export_file_type
        _create_configuration_file_param.machine_image_id = _machine_image_id
        _create_configuration_file_param.number_of_drives = _number_of_drives
        _create_configuration_file_param.address_setting = _address_setting
        param_arr = []
        param_arr.append('index')
        param_arr.append('control_port_ipv4_address')
        param_arr.append('internode_port_ipv4_address')
        param_arr.append('compute_port_ipv4_address')
        param_arr.append('compute_port_ipv6_address')

        from com.hitachi.sophia.rest_client.autogen.models.ConfigurationFileAddressSetting import ConfigurationFileAddressSetting
        arr = []
        param_name = "address_setting"

        if _address_setting is not None:
            for __value in _address_setting:
                configuration_file_address_setting = ConfigurationFileAddressSetting()
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'integer' ,'index',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'integer' ,'index',param_name)


                configuration_file_address_setting.index = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'string' ,'control_port_ipv4_address',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'string' ,'control_port_ipv4_address',param_name)


                configuration_file_address_setting.control_port_ipv4_address = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'string' ,'internode_port_ipv4_address',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'string' ,'internode_port_ipv4_address',param_name)


                configuration_file_address_setting.internode_port_ipv4_address = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'string' ,'compute_port_ipv4_address',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'string' ,'compute_port_ipv4_address',param_name)


                configuration_file_address_setting.compute_port_ipv4_address = tempval
                tempval = None
                tempval = ObjectArrayUtil.getArrayParamValue(__value,'string' ,'compute_port_ipv6_address',param_arr,param_name)

                #型変換実施
                tempval = ObjectArrayUtil.convertType(tempval,'string' ,'compute_port_ipv6_address',param_name)


                configuration_file_address_setting.compute_port_ipv6_address = tempval
                arr.append(configuration_file_address_setting)
            _create_configuration_file_param.address_setting = arr
        _create_configuration_file_param.recover_single_drive = _recover_single_drive
        _create_configuration_file_param.drive_id = _drive_id
        _create_configuration_file_param.recover_single_node = _recover_single_node
        _create_configuration_file_param.node_id = _node_id
        _create_configuration_file_param.template_s3_url = _template_s3_url

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.configuration_file_create(create_configuration_file_param = _create_configuration_file_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def configuration_file_download():
    """
    Downloads a configuration file. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "configuration_file_download"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "configuration_file_download"












                

    
        
        
        
        
        try:



            if not ('Authorization' in config.api_key):
                warningbanner = WarningBanner()
                warningbanner.sub_command_name = cliSubCommand
                login_message_response = warningbanner.get_login_message()
                login_message = warningbanner.view_warning_banner(login_message_response)

                commonutil.view_error()

                #空文字,Nullの場合はログインメッセージを表示しない
                if(login_message):
                    click.echo(login_message, err=True)

            commonutil.input_password()




            # ストレージクラスターとCLIのバージョンチェック
            versioncheck = VersionCheck()
            api_version_response = versioncheck.get_api_version()
            versioncheck.version_check(api_version_response)

            response = api.configuration_file_download(callback=None, debug="false" ,_preload_content=False)

        # print(response)
            if(response):
            
                cli_response = collections.OrderedDict()
                cli_response['httpStatusCode'] = response.status
            
                if(response.status!=200):
                    if response.data:
                        cli_response['body'] = ApiClient().deserialize_json_to_body_or_exit(response, _preload_content=False)
                    
                    data = json.dumps(cli_response, indent=4, separators=(',', ': '))
                    output_util = OutputUtil()
                    output_util.echo_normal(data, config.format, cliSubCommand)

                    #click.echo(data)
                    exit(commonutil.get_cli_exit_code_for_api_execution(response.status))

        except Exception as e:
            if (traceback):
                logger.error(traceback.format_exc())
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessage(e)

        defaultFileName = FileUtil.getFileNameWithResponse(response)
        fileutil = FileUtil(defaultFileName)

        dirname, filename = fileutil.locate_download_file(defaultFileName)
        download_path = os.path.join(dirname, filename)
        saveFile = None
        try:
            with open(download_path, 'wb') as saveFile:
                saveFile.write(response.data)
            if config.format == 'text':
                click.echo('Message: ' + 'Download completed.')
                click.echo('Output File Path: ' + os.path.abspath(defaultFileName))
            else:
                cli_response['message'] = 'Download completed.'
                cli_response['outputFilePath'] = os.path.abspath(defaultFileName)
                cli_response = json.dumps(cli_response, indent=4, separators=(',', ': '))
                click.echo(cli_response)

            #cli_response['outputFilePath'] = os.path.abspath(defaultFileName)
            cli_response = json.dumps(cli_response, indent=4, separators=(',', ': '))
            #click.echo(cli_response)

        except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
            messageId = '19007'
            messageDict = {
                'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                    defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except FileExistsError as e:  # 既にファイルが存在している
            messageId = '19007'
            messageDict = {'exception': 'A file has already existed. (File path = ' + os.path.abspath(defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except OSError as e:  # OSError かつ errno ENOSPCの場合
            if e.errno == errno.ENOSPC:
                messageId = '19007'
                messageDict = {
                    'exception': 'No more space for writing is available on the device. (File path = ' + os.path.abspath(
                        defaultFileName) + ')'}
                mssageManagement = MessageManagement('')
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)

            else:
                messageId = '19007'
                strErr = ','.join(map(str, e.args))
                messageDict = {'exception': strErr}
                mssageManagement = MessageManagement('')
                mssageManagement.viewMessageTxt(messageId, **messageDict)
                exit(1)

        except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
            messageId = '19007'
            messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(defaultFileName) + ')'}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)

        except Exception as e:
            #ファイルの保存に失敗
            messageId = '19007'
            strErr = ' '.join(map(str, e.args))
            messageDict = {'exception': strErr}
            mssageManagement = MessageManagement('')
            mssageManagement.viewMessageTxt(messageId, **messageDict)

            exit(1)
        finally:
            if (saveFile):
                saveFile.close()

        #print('Download external auth server crl file Success')
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--storage_node_id','_storage_node_id',metavar='<str>',help='Storage node ID. ')
def control_port_list(_storage_node_id,):
    """
    Obtains a list of control port information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "control_port_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _storage_node_id is not None:
            subCommandLogtxt += "--storage_node_id " + str(_storage_node_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        #UUIDチェック
        if _storage_node_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _storage_node_id):
            raise ValueError("Invalid value for `storage_node_id`, the format of UUID is invalid.")
        


        
        
        
        
        
        #cliSubCommand = "control_port_list"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ControlPortList import ControlPortList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.control_port_list(storage_node_id = _storage_node_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Control port ID ',required=True)
def control_port_show(_id,):
    """
    Obtains control port information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "control_port_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "control_port_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.ControlPort import ControlPort

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.control_port_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--storage_node_id','_storage_node_id',metavar='<str>',help='Storage node ID. ')
def internode_port_list(_storage_node_id,):
    """
    Obtains a list of internode port information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "internode_port_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _storage_node_id is not None:
            subCommandLogtxt += "--storage_node_id " + str(_storage_node_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        #UUIDチェック
        if _storage_node_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _storage_node_id):
            raise ValueError("Invalid value for `storage_node_id`, the format of UUID is invalid.")
        


        
        
        
        
        
        #cliSubCommand = "internode_port_list"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.InternodePortList import InternodePortList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.internode_port_list(storage_node_id = _storage_node_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Internode port ID ',required=True)
def internode_port_show(_id,):
    """
    Obtains the internode port information. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "internode_port_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "internode_port_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.InternodePort import InternodePort

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.internode_port_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def storage_resume_suppressed_start_processing():
    """
    Forcibly starts the storage cluster. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_resume_suppressed_start_processing"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()









        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_resume_suppressed_start_processing"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.resume_suppressed_start_processing(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--is_enabled','_is_enabled',metavar='<bool>',help='Enables or disables the auto-recovery function. Specifying true enables the auto-recovery function.')
@click.option('--storage_node_persistent_blocking_threshold_time','_storage_node_persistent_blocking_threshold_time',type=int,metavar='<int>',help='The time to determine if the temporarily blocked storage node that was recovered previously is changed to persistent blockage status (unit: hours).')
@click.option('--spare_node_switchover_waiting_time','_spare_node_switchover_waiting_time',type=int,metavar='<int>',help='Waiting time until spare node switchover for a blocked storage node is to be performed after the storage node is blocked temporarily (unit: minutes). (Bare metal)')
def storage_auto_recovery_setting_set(_is_enabled,_storage_node_persistent_blocking_threshold_time,_spare_node_switchover_waiting_time,):
    """
    Changes the auto-recovery function settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_auto_recovery_setting_set"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        if _is_enabled is not None:
            subCommandLogtxt += "--is_enabled " + str(_is_enabled) + " "




        if _storage_node_persistent_blocking_threshold_time is not None:
            subCommandLogtxt += "--storage_node_persistent_blocking_threshold_time " + str(_storage_node_persistent_blocking_threshold_time) + " "




        if _spare_node_switchover_waiting_time is not None:
            subCommandLogtxt += "--spare_node_switchover_waiting_time " + str(_spare_node_switchover_waiting_time) + " "








        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        


        
        


        
        
        
        
        
        #cliSubCommand = "storage_auto_recovery_setting_set"



















        if _is_enabled is not None:
            if(isinstance(_is_enabled, str)):
                _is_enabled = SeparateArgs.check_backslash(_is_enabled)
                _is_enabled = _is_enabled.encode("utf-8").decode("unicode-escape")
        if _storage_node_persistent_blocking_threshold_time is not None:
            if(isinstance(_storage_node_persistent_blocking_threshold_time, str)):
                _storage_node_persistent_blocking_threshold_time = SeparateArgs.check_backslash(_storage_node_persistent_blocking_threshold_time)
                _storage_node_persistent_blocking_threshold_time = _storage_node_persistent_blocking_threshold_time.encode("utf-8").decode("unicode-escape")
        if _spare_node_switchover_waiting_time is not None:
            if(isinstance(_spare_node_switchover_waiting_time, str)):
                _spare_node_switchover_waiting_time = SeparateArgs.check_backslash(_spare_node_switchover_waiting_time)
                _spare_node_switchover_waiting_time = _spare_node_switchover_waiting_time.encode("utf-8").decode("unicode-escape")



                
        from com.hitachi.sophia.rest_client.autogen.models.PatchStorageAutoRecoverySettingParam import PatchStorageAutoRecoverySettingParam
        _patch_storage_auto_recovery_setting_param = PatchStorageAutoRecoverySettingParam()
        _patch_storage_auto_recovery_setting_param.is_enabled = _is_enabled
        _patch_storage_auto_recovery_setting_param.storage_node_persistent_blocking_threshold_time = _storage_node_persistent_blocking_threshold_time
        _patch_storage_auto_recovery_setting_param.spare_node_switchover_waiting_time = _spare_node_switchover_waiting_time

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_auto_recovery_setting_set(patch_storage_auto_recovery_setting_param = _patch_storage_auto_recovery_setting_param, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def storage_auto_recovery_setting_show():
    """
    Obtains the settings and status of the auto-recovery function. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_auto_recovery_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "storage_auto_recovery_setting_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageAutoRecoverySetting import StorageAutoRecoverySetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_auto_recovery_setting_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def storage_configuration_summary_show():
    """
    Obtains a summary of the storage cluster configuration. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_configuration_summary_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "storage_configuration_summary_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageConfigurationSummary import StorageConfigurationSummary

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_configuration_summary_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def storage_master_node_primary_flag_show():
    """
    Obtains the information showing whether the storage node is the storage cluster master node (primary) or not. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('','','')
        auth_parameter_util.check_auth_parameter('','','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_master_node_primary_flag_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "storage_master_node_primary_flag_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageMasterNodePrimaryFlag import StorageMasterNodePrimaryFlag

    
        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_master_node_primary_flag_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def storage_network_setting_show():
    """
    Obtains the storage cluster network settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_network_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "storage_network_setting_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNetworkSetting import StorageNetworkSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_network_setting_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--storage_node_id','_storage_node_id',metavar='<str>',help='Storage node ID. ')
def storage_node_network_setting_list(_storage_node_id,):
    """
    Obtains a list of storage node network settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_network_setting_list"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()





        if _storage_node_id is not None:
            subCommandLogtxt += "--storage_node_id " + str(_storage_node_id) + " "






        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        #UUIDチェック
        if _storage_node_id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _storage_node_id):
            raise ValueError("Invalid value for `storage_node_id`, the format of UUID is invalid.")
        


        
        
        
        
        
        #cliSubCommand = "storage_node_network_setting_list"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNodeNetworkSettingList import StorageNodeNetworkSettingList

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_node_network_setting_list(storage_node_id = _storage_node_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--id','_id',metavar='<str>',help='Storage node ID ',required=True)
def storage_node_network_setting_show(_id,):
    """
    Obtains the storage node network settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_node_network_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _id is not None:
            subCommandLogtxt += "--id " + str(_id) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())



        
        #UUIDチェック
        if _id is not None and not re.search('^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$', _id):
            raise ValueError("Invalid value for `id`, the format of UUID is invalid.")
        
        


        
        
        
        
        
        #cliSubCommand = "storage_node_network_setting_show"


















                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageNodeNetworkSetting import StorageNodeNetworkSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_node_network_setting_show(_id, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
def storage_time_setting_show():
    """
    Obtains the storage cluster time settings. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "storage_time_setting_show"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())

        


        
        
        
        
        
        #cliSubCommand = "storage_time_setting_show"












                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.StorageTimeSetting import StorageTimeSetting

    
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.storage_time_setting_show(callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    



@click.command(options_metavar='<options>')
@click.option('--system_requirements_file','_system_requirements_file',metavar='<file>',help='The system requirements file that is imported to the storage cluster. ',required=True)
def system_requirements_file_import(_system_requirements_file,):
    """
    Imports the system requirements file. 
    """

    try:

        #master commandでエラーがあった場合はエラー表示して処理停止
        commonutil = CommonUtil()
        commonutil.view_error()
        config = Configuration()

        auth_parameter_util = AuthParametersUtil()
        auth_parameter_util.set_auth_parameter('true','true','')
        auth_parameter_util.check_auth_parameter('true','true','')

        commonutil.view_error()

        subCommandLogtxt = "Sub-command parameters : " + " "

        cliSubCommand = "system_requirements_file_import"

        # formatがsimple-csvの場合、サポートしているサブコマンドかチェック
        if config.format == 'simple-csv':
            OutputUtil().check_format_csv(cliSubCommand)
            commonutil.view_error()




        if _system_requirements_file is not None:
            subCommandLogtxt += "--system_requirements_file " + str(_system_requirements_file) + " "







        logger.info(subCommandLogtxt)

        
        from com.hitachi.sophia.rest_client.autogen.apis.system_management import SystemManagement as SystemManagementApi
        api = SystemManagementApi(ApiClient())



        
        
        


        
        


        
        
        
        
        
        #cliSubCommand = "system_requirements_file_import"
























                

    
        
        from com.hitachi.sophia.rest_client.autogen.models.Job import Job

    
        
        
        
        #ファイルが存在するか
        if not(os.path.isfile(_system_requirements_file)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_system_requirements_file)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)
        
        


        if not ('Authorization' in config.api_key):
            warningbanner = WarningBanner()
            warningbanner.sub_command_name = cliSubCommand
            login_message_response = warningbanner.get_login_message()
            login_message = warningbanner.view_warning_banner(login_message_response)

            commonutil.view_error()

            #空文字,Nullの場合はログインメッセージを表示しない
            if(login_message):
                click.echo(login_message, err=True)

        commonutil.input_password()

        
        
        
        #ファイルが存在するか 2回目
        if not(os.path.isfile(_system_requirements_file)):
            mssageManagement = MessageManagement('')
            messageId = '19004'
            messageDict = {'filePath': os.path.abspath(_system_requirements_file)}
            mssageManagement.viewMessageTxt(messageId, **messageDict)
            exit(1)
        
        




        # ストレージクラスターとCLIのバージョンチェック
        versioncheck = VersionCheck()
        api_version_response = versioncheck.get_api_version()
        versioncheck.version_check(api_version_response)

        response = api.system_requirements_file_import(_system_requirements_file, callback=None, debug="false")

        # click.echo(response)
        oup = OutputUtil()
        oup.echo_normal(response, config.format, cliSubCommand)
        status = commonutil.get_response_status(response)
        exit(commonutil.get_cli_exit_code_for_api_execution(status))
        
        
        
        
        
        
        
    except PermissionError as e:  # 十分なアクセス権、例えばファイルシステム権限のない操作
        messageId = '19007'
        messageDict = {
            'exception': 'An operation was attempted without adequate access rights, such as file system rights. (File path = ' + os.path.abspath(
                _system_requirements_file) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except KeyboardInterrupt as e:  # Control-C または Deleteを押した場合
        messageId = '19007'
        messageDict = {'exception': 'The user hit the interrupt key. (File path = ' + os.path.abspath(_system_requirements_file) + ')'}
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessageTxt(messageId, **messageDict)
        exit(1)

    except Exception as e:
        if(traceback):
            logger.error(traceback.format_exc())
        mssageManagement = MessageManagement('')
        mssageManagement.viewMessage(e)
    
    






def commands():
    commands= {}

    commands['configuration_file_create'] = configuration_file_create
    commands['configuration_file_download'] = configuration_file_download

    commands['control_port_list'] = control_port_list
    commands['control_port_show'] = control_port_show

    commands['internode_port_list'] = internode_port_list
    commands['internode_port_show'] = internode_port_show





    commands['storage_resume_suppressed_start_processing'] = storage_resume_suppressed_start_processing
    commands['storage_auto_recovery_setting_set'] = storage_auto_recovery_setting_set
    commands['storage_auto_recovery_setting_show'] = storage_auto_recovery_setting_show
    commands['storage_configuration_summary_show'] = storage_configuration_summary_show
    commands['storage_master_node_primary_flag_show'] = storage_master_node_primary_flag_show
    commands['storage_network_setting_show'] = storage_network_setting_show




    commands['storage_node_network_setting_list'] = storage_node_network_setting_list
    commands['storage_node_network_setting_show'] = storage_node_network_setting_show


    commands['storage_time_setting_show'] = storage_time_setting_show
    commands['system_requirements_file_import'] = system_requirements_file_import
    return commands


"""
All rights reserved. Copyright (C) 2019, 2024, Hitachi Vantara, Ltd.
"""


import os
import re
import json
import logging as loggingLib
from typing import List, Optional, Tuple

logger = loggingLib.getLogger(__name__)


class ConfigfileUtil(object):
    def get_control_address_from_csv(self, conf_csv_file):
        rtrn = 0 
        control_addr = []
        errmsg = ''
        try:
            if(not os.path.exists(conf_csv_file)):
                # ファイルが存在しない
                rtrn = 1
                errmsg = "The specified file does not exist."
                return rtrn, control_addr, errmsg

            # ファイル読み込み
            f = open(conf_csv_file, "r")
            line = f.readline()
            nodes_flg = False
            NodsValue = []
            while line:
                # Nodesセクション - 次のセクションまでの値を取得する
                wkstr = line.rstrip()
                if re.match("^\[[a-zA-Z0-9]+\]", wkstr):
                    blockname = wkstr.strip("[],")
                    if blockname == "Nodes":
                        nodes_flg = True
                    else:
                        if nodes_flg:
                            nodes_flg = False
                if nodes_flg:
                    NodsValue.append(wkstr)
                line = f.readline()
            f.close()

            # ControlNWIPv4列の取得
            colm_idx = 0
            control_addr_colm = "ControlNWIPv4"
            Nodscolm = NodsValue[1].split(',')
            for controlNWIPv4 in Nodscolm:
                if controlNWIPv4 == control_addr_colm:
                    break
                colm_idx += 1

            for row in NodsValue[2:]:
                control_addr.append(row.split(',')[colm_idx])

        except UnicodeDecodeError:
            rtrn = 2
            errmsg = "The encoding method of the configuration file is not UTF-8."
            # 構成ファイル(csv)のエンコーディングがUTF-8でない

        except Exception:
            rtrn = 3
            errmsg = "The configuration file is invalid."
            # 構成ファイル(csv)読み込みで例外発生

        return rtrn, control_addr, errmsg

    def get_control_address_from_vm_configuration_file(self, conf_file: str) -> Tuple[int, List[str], str]:
        logger.info(f"Start parsing the configuration file. conf_file = {conf_file}")
        rtrn = 0
        control_addr: List[str] = []
        errmsg = ''

        # conf_file が存在するかをチェック
        if not os.path.exists(conf_file):
            # ファイルが存在しない
            logger.error("The specified file does not exist.")
            rtrn = 1
            errmsg = "The specified file does not exist."
            return rtrn, control_addr, errmsg

        # UTF-8かどうかをチェック
        try:
            with open(conf_file, 'r') as f:
                f.read()
        except UnicodeDecodeError:
            # 構成ファイルのエンコーディングがUTF-8でない
            logger.error("The encoding method of the configuration file is not UTF-8.")
            rtrn = 2
            errmsg = "The encoding method of the configuration file is not UTF-8."
            return rtrn, control_addr, errmsg

        # YAMLフォーマットとしてパース
        yaml_control_addr = self.get_control_address_from_yaml(conf_file)
        if yaml_control_addr is not None:
            # YAMLフォーマットとしてパースできた
            logger.info(f"successfully parsed as yaml. yaml_control_addr = {yaml_control_addr}")
            control_addr = yaml_control_addr
            return rtrn, control_addr, errmsg

        # YAMLフォーマットとしてパース(Marketplace版)
        yaml_control_addr = self.get_control_address_from_yaml_for_maketplace(conf_file)
        if yaml_control_addr is not None:
            # YAMLフォーマットとしてパースできた
            logger.info(f"successfully parsed as yaml (Marketplace). yaml_control_addr = {yaml_control_addr}")
            control_addr = yaml_control_addr
            return rtrn, control_addr, errmsg

        # JSONフォーマットとしてパース
        json_control_addr = self.get_control_address_from_json(conf_file)
        if json_control_addr is not None:
            # JSONフォーマットとしてパースできた
            logger.info(f"successfully parsed as json. json_control_addr = {json_control_addr}")
            control_addr = json_control_addr
            return rtrn, control_addr, errmsg

        # TFVARSフォーマットとしてパース
        tfvars_control_addr = self.get_control_address_from_tfvars(conf_file)
        if tfvars_control_addr is not None:
            # TFVARSフォーマットとしてパースできた
            logger.info(f"successfully parsed as tfvars. tfvars_control_addr = {tfvars_control_addr}")
            control_addr = tfvars_control_addr
            return rtrn, control_addr, errmsg

        # YAML/JSON/TFVARSフォーマットとしてパースできなかった
        logger.error("The configuration file is invalid.")
        rtrn = 3
        errmsg = "The configuration file is invalid."
        return rtrn, control_addr, errmsg

    # AWS版 VMConfigurationFile.ymlから管理ポートIPアドレスを取得する
    def get_control_address_from_yaml(self, conf_vm_file: str) -> Optional[List[str]]:
        logger.info(f"Start parsing the configuration file as yaml. conf_vm_file = {conf_vm_file}")
        control_addr: List[str] = []
        try:
            # yamlライブラリはpython標準ではないため使用しない
            # 作成されたストレージノードの数を確認
            created_storage_node_count = 0
            with open(conf_vm_file, "r") as f:
                lines = f.readlines()
                for line in lines:
                    if "StorageNodeCreate" in line and "Equals" in line and "[ON, ON]" in line:
                        created_storage_node_count += 1
            if created_storage_node_count == 0:
                # 期待するYAMLフォーマットではなかった
                logger.info("Storage node does not exitst. The file is not expected yaml format.")
                return None

            # IPアドレスを確認
            # ヒットする例↓(m.group(1) = 10.160.165.5)
            # ControlNetworkIpv4Address01:
            # Type: String
            # Default: 10.160.165.5
            pattern = re.compile(r'ControlNetworkIpv4Address(\d{1,3}|TB):\s+Type:\s*String\s+Default:\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', re.MULTILINE | re.DOTALL)
            match_ip_address_count = 0
            with open(conf_vm_file, "r") as f:
                data = f.read()
                for m in pattern.finditer(data):
                    control_addr.append(m.group(2))
                    match_ip_address_count += 1
                    if match_ip_address_count == created_storage_node_count:
                        # 作成されたストレージノード数よりも多くIPアドレスが入力されていても無視する
                        break
                if match_ip_address_count < created_storage_node_count:
                    # YAMLフォーマットではあるが、IPアドレスが不足している
                    logger.error("Not match ip address. matched_ipaddress = {}. created_storagenode = {}.".format(match_ip_address_count, created_storage_node_count))
                    return None
        except Exception:
            # 構成ファイル(yaml)読み込みで例外発生
            logger.exception("something wrong in reading yaml file.")
            return None

        logger.info(f"control_addr = {control_addr}")
        return control_addr

    # AWS(Marketplace)版 NetworkResourceConfigurationFile.ymlから管理ポートIPアドレスを取得する
    def get_control_address_from_yaml_for_maketplace(self, conf_vm_file: str) -> Optional[List[str]]:
        logger.info(f"Start parsing the configuration file as yaml (Marketplace). conf_vm_file = {conf_vm_file}")
        control_addr: List[str] = []
        try:
            # ControlIpv4AddressセクションのIPアドレスを抽出
            # ヒットする例↓(m.group(2) = "10.160.165.5")
            # Mappings:
            #  NetworkAddress:
            #   ControlIpv4Address:
            #    SN01: "10.160.165.5"
            pattern = re.compile(r'(SN\d{2}|TB):\s*["\']?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})["\']?')
            is_controlnetworkaddress = False
            is_mappings = False
            is_networkaddress = False
            match_ip_address_count = 0
            with open(conf_vm_file, "r") as f:
                lines = f.readlines()
                for line in lines:
                    if "Mappings:" in line:
                        is_mappings = True
                    if "Parameters:" in line or "Resources:"  in line or "Outputs:" in line or "Conditions:" in line:
                        is_mappings = False
                        is_networkaddress = False
                        is_controlnetworkaddress = False
                    if "NetworkAddress:" in line:
                        is_networkaddress = True
                    if "ControlIpv4Address:" in line:
                        is_controlnetworkaddress = True
                    if "InternodeIpv4Address:" in line or "ComputeIpv4Address:" in line or "ComputeIpv6Address:" in line:
                        is_controlnetworkaddress = False
                    if is_networkaddress and is_controlnetworkaddress and is_mappings:
                        m = pattern.search(line)
                        if m:
                            address = m.group(2).replace('"', '').replace("'", '')
                            control_addr.append(address)
                            match_ip_address_count += 1
                if match_ip_address_count == 0:
                    # YAMLフォーマットではあるが、IPアドレスが不足している
                    logger.error("Not match ip address (Marketplace). ")
                    return None

        except Exception:
            logger.exception("Something wrong in reading yaml file (Marketplace).")
            return None

        logger.info(f"control_addr = {control_addr}")
        return control_addr

    # Azure版 VMConfigurationFile.parameters.jsonから管理ポートIPアドレスを取得する
    def get_control_address_from_json(self, conf_json_file: str) -> Optional[List[str]]:
        logger.info(f"Start parsing the configuration file as json. conf_json_file = {conf_json_file}")
        control_addr: List[str] = []
        try:
            # 作成されたストレージノードの数を確認
            created_storage_node_count = 0
            with open(conf_json_file, 'r') as f:
                data = json.load(f)
                if 'numberOfNodes' in data['parameters']:
                    created_storage_node_count = data['parameters']['numberOfNodes']['value']

                if created_storage_node_count == 0:
                    # 期待するJSONフォーマットではなかった
                    logger.info("Storage node does not exitst. The file is not expected json format.")
                    return None

            # 管理ポートアドレス数を確認
            control_addr_count = 0
            if 'controlIPv4AddressArray' in data['parameters']:
                control_addr = data['parameters']['controlIPv4AddressArray']['value']
                control_addr_count = len(control_addr)

            if control_addr_count < created_storage_node_count:
                # JSONフォーマットではあるが、IPアドレスが不足している
                logger.error("Not match ip address. matched_ipaddress = {}. created_storagenode = {}.".format(control_addr_count, created_storage_node_count))
                return None

        except Exception:
            # 構成ファイル(json)読み込みで例外発生
            logger.exception("something wrong in reading json file.")
            return None

        logger.info(f"control_addr = {control_addr}")
        return control_addr

    # GCP版 terraform.tfvarsから管理ポートIPアドレスを取得する
    def get_control_address_from_tfvars(self, conf_tfvars_file: str) -> Optional[List[str]]:
        logger.info(f"Start parsing the configuration file as tf. conf_tfvars_file = {conf_tfvars_file}")
        control_addr: List[str] = []
        try:
            # 作成されたストレージノードの数を確認
            created_storage_node_count = 0
            with open(conf_tfvars_file, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    if 'numberOfNodes' in line:
                        created_storage_node_count = int(line.split('=')[1].strip())
                        break

                if created_storage_node_count == 0:
                    # 期待するtfvarsフォーマットではなかった
                    logger.info("Storage node does not exitst. The file is not expected tfvars format.")
                    return None

            # 管理ポートアドレス数を確認
            control_addr_count = 0
            for line in lines:
                if 'controlIPv4AddressArray' in line:
                    # B#240119 controlIPv4AddressArray =' に続く'['と']'で囲まれた文字列をjsonパーサーに渡して配列を読み込む
                    control_addr = json.loads(line.split('=')[1].strip())
                    control_addr_count = len(control_addr)
                    break

            if control_addr_count < created_storage_node_count:
                # tfvarsフォーマットではあるが、IPアドレスが不足している
                logger.error("Not match ip address. matched_ipaddress = {}. created_storagenode = {}.".format(control_addr_count, created_storage_node_count))
                return None

        except Exception:
            # 構成ファイル(tfvars)読み込みで例外発生
            logger.exception("something wrong in reading tfvars file.")
            return None

        logger.info(f"control_addr = {control_addr}")
        return control_addr

    def get_first_master_node(self, conf_csv_file):
        rtrn = 0 
        first_master_ipaddr = ''
        errmsg = ''
        try:
            if(not os.path.exists(conf_csv_file)):
                # ファイルが存在しない
                rtrn = 1
                errmsg = "The specified file does not exist."
                return rtrn, first_master_ipaddr, errmsg

            # ファイル読み込み
            f = open(conf_csv_file, "r")
            line = f.readline()
            nodes_flg = False
            NodsValue = []
            while line:
                # Nodesセクション - 次のセクションまでの値を取得する
                wkstr = line.rstrip()
                if re.match("^\[[a-zA-Z0-9]+\]", wkstr):
                    blockname = wkstr.strip("[],")
                    if blockname == "Nodes":
                        nodes_flg = True
                    else:
                        if nodes_flg:
                            nodes_flg = False
                if nodes_flg:
                    NodsValue.append(wkstr)
                line = f.readline()
            f.close()

            # ControlNWIPv4列と、clustermasterの取得
            colm_idx = 0
            master_idx = 0
            control_addr_colm = "ControlNWIPv4"
            cluster_role_colm = "ClusterMasterRole"
            Nodscolm = NodsValue[1].split(',')
            for colm in Nodscolm:
                if colm == cluster_role_colm:
                    # clustermasterの行目を取得
                    master_idx = colm_idx
                if colm == control_addr_colm:
                    break
                colm_idx += 1

            for row in NodsValue[2:]:
                if row.split(',')[master_idx] == 'clustermaster':
                    first_master_ipaddr = row.split(',')[colm_idx]
                    break

        except UnicodeDecodeError:
            rtrn = 2
            errmsg = "The encoding method of the configuration file is not UTF-8."
            # 構成ファイル(csv)のエンコーディングがUTF-8でない

        except Exception:
            rtrn = 3
            errmsg = "The configuration file is invalid."
            # 構成ファイル(csv)読み込みで例外発生

        return rtrn, first_master_ipaddr, errmsg
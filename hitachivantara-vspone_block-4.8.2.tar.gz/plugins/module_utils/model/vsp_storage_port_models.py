from dataclasses import dataclass, asdict, fields
from typing import Optional, List

try:
    from .common_base_models import BaseDataClass, SingleBaseClass
except ImportError:
    from common_base_models import BaseDataClass, SingleBaseClass


PORT_TYPE_CHOICES = ["fibre", "scsi", "iscsi", "nvme_tcp", "enas", "escon", "ficon"]


@dataclass
class ShortPortInfo(SingleBaseClass):
    portId: Optional[str] = None
    portType: Optional[str] = None
    portAttributes: Optional[List[str]] = None
    portSpeed: Optional[str] = None
    loopId: Optional[str] = None
    fabricMode: Optional[bool] = None
    portConnection: Optional[str] = None
    portSecuritySetting: Optional[bool] = None
    wwn: Optional[str] = None
    portMode: Optional[str] = None

    def to_dict(self):
        return asdict(self)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        for field in fields(self):
            if field.name not in kwargs:
                setattr(self, field.name, None)
            if kwargs.get("lunSecuritySetting"):
                self.portSecuritySetting = kwargs.get("lunSecuritySetting")


@dataclass
class ShortPortInfoList(BaseDataClass):
    data: List[ShortPortInfo] = None


@dataclass
class PingInfo(SingleBaseClass):
    receivedPackets: Optional[int] = None
    transmittedPackets: Optional[int] = None


@dataclass
class PortInfo(SingleBaseClass):
    portId: Optional[str] = None
    portType: Optional[str] = None
    portAttributes: Optional[List[str]] = None
    portSpeed: Optional[str] = None
    loopId: Optional[str] = None
    fabricMode: Optional[bool] = None
    portConnection: Optional[str] = None
    portSecuritySetting: Optional[bool] = None
    wwn: Optional[str] = None
    logins: Optional[List] = None
    tcpMtu: Optional[str] = None
    iscsiWindowSize: Optional[str] = None
    keepAliveTimer: Optional[int] = None
    tcpPort: Optional[str] = None
    macAddress: Optional[str] = None
    ipv4Address: Optional[str] = None
    ipv4Subnetmask: Optional[str] = None
    ipv4GatewayAddress: Optional[str] = None
    portMode: Optional[str] = None
    # portAttributes: Optional[List] = None

    def to_dict(self):
        return asdict(self)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        for field in fields(self):
            if field.name not in kwargs:
                setattr(self, field.name, None)
            if kwargs.get("lunSecuritySetting"):
                self.portSecuritySetting = kwargs.get("lunSecuritySetting")


@dataclass
class PortsInfo(BaseDataClass):
    data: List[PortInfo] = None


@dataclass
class ExternalIscsiTarget:
    ip_address: Optional[str] = None
    name: Optional[str] = None
    tcp_port: Optional[int] = None


@dataclass
class ChangePortSettingSpec:
    port: Optional[str] = None
    port_id: Optional[str] = None
    port_attribute: Optional[str] = None
    port_mode: Optional[str] = None
    port_speed: Optional[str] = None
    fabric_mode: Optional[bool] = None
    port_connection: Optional[str] = None
    enable_port_security: Optional[bool] = None
    host_ip_address: Optional[str] = None
    external_iscsi_targets: Optional[List[ExternalIscsiTarget]] = None

    def __post_init__(self):
        if self.port_id:
            self.port = self.port_id


@dataclass
class PortFactSpec:
    ports: Optional[List] = None
    port_ids: Optional[List] = None
    query: Optional[List[str]] = None
    external_iscsi_ip_address: Optional[str] = None
    external_iscsi_name: Optional[str] = None
    external_tcp_port: Optional[int] = None
    external_wwn: Optional[str] = None
    port_type: Optional[str] = None

    def __post_init__(self):
        if self.port_type:
            if self.port_type.lower() not in PORT_TYPE_CHOICES:
                raise ValueError(
                    f"Invalid port_type: {self.port_type}. Must be one of {PORT_TYPE_CHOICES} and case insensitive."
                )
            self.port_type = self.port_type.upper()
        if self.port_ids:
            self.ports = self.port_ids
